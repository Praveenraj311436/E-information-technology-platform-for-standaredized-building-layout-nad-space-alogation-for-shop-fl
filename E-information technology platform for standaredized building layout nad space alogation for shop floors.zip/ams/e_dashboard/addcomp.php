<?php include('../header_emp.php');
if(!isset($_SESSION['objLogin'])){
	header("Location: ".WEB_URL."logout.php");
	die();
}
include(ROOT_PATH.'language/'.$lang_code_global.'/lang_employee_rented_details.php');
?>
<!-- Content Header (Page header) -->

<section class="content-header">
  <h1> <?php echo "Add Complain";?> </h1>
  <ol class="breadcrumb">
    <li><a href="<?php echo WEB_URL?>dashboard.php"><i class="fa fa-dashboard"></i> <?php echo $_data['home_breadcam'];?></a></li>
	<li class="active"><?php echo $_data['text_1'];?></li>
  </ol>
</section>
<!-- Main content -->
<section class="content">
<!-- Full Width boxes (Stat box) -->
<div class="row">
  <div class="col-xs-12">
    <div align="right" style="margin-bottom:1%;"><a class="btn btn-primary" data-toggle="tooltip" href="<?php echo WEB_URL; ?>e_dashboard.php" data-original-title="<?php echo $_data['dashboard'];?>"><i class="fa fa-dashboard"></i></a> </div>
    <div class="box box-info">
      <div class="box-header">
        <h3 class="box-title"><?php echo "Add Complain";?></h3>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
               <div class="container">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <form class="form-horizontal" action="" method="post">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Name:</label>
      <div class="col-sm-6">
        <input type="text" class="form-control"  placeholder="name" name="e_name">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">E-mail:</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control"  placeholder="email" name="e_email">
      </div>
    </div>
       <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Contact:</label>
      <div class="col-sm-6">          
        <input type="text" class="form-control"  placeholder="contact" name="e_contact">
      </div>
    </div>
       <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Query:</label>
      <div class="col-sm-6">          
        <textarea rows="4" cols="50" class="form-control">

</textarea>
      </div>
    </div>
     
    
     
      
   
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-success" name = "submit">send</button>
      </div>
    </div>
  </form>
<!--
             <?php
if(isset($_POST['submit']))
{
  $conn  = mysql_connect('localhost','root','');
    mysql_select_db("ams_mb", $conn);
   
    $name = $_POST['e_name'];
    $email = $_POST['e_email'];
      $con = $_POST['e_contact'];
      $add= $_POST['e_pre_address'];
      $branch_id = $_POST['branch_id'];
    $designation = $_POST['e_designation'];
    date_default_timezone_set('Asia/Kolkata');
		$trn_date = date("Y-m-d H:i:s");
    mysql_query("INSERT INTO `tbl_add_employee`(`e_name`, `e_email`, `e_contact`, `e_pre_address`,`branch_id`,`e_designation`,`e_date`) VALUES ('$name','$email','$con','$add','$branch_id','$designation','$trn_date')");
    
    echo "inserted successfully";
}

?>
-->
</div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->
<?php include('../footer.php'); ?>
