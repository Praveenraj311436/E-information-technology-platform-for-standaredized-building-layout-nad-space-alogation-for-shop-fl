<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Employee Salary Setup";
$_data['text_2'] 		= "Employee Salary Entry Form";
$_data['text_3'] 		= "Employee Name";
$_data['text_4'] 		= "Select Name";
$_data['text_5'] 		= "Designation";
$_data['text_6'] 		= "Select Month";
$_data['text_7'] 		= "Amount ";
$_data['text_8'] 		= "Issue Date";
$_data['text_9'] 		= "Added Employee Salary Information Successfully";
$_data['text_10'] 		= "Updated Employee Salary Information Successfully";
$_data['text_11'] 		= "Deleted Employee Salary Information Successfully";
$_data['text_12'] 		= "Employee Salary Details";
$_data['text_13'] 		= "Name";
$_data['text_14'] 		= "Email";
$_data['text_15'] 		= "Phone";

?>