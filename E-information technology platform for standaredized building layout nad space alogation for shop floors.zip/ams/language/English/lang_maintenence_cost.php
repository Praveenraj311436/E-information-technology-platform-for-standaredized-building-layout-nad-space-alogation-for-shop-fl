<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Maintenance Cost List";
$_data['text_2'] 		= "Maintenance Title";
$_data['text_3'] 		= "Date";
$_data['text_4'] 		= "Amount";
$_data['text_5'] 		= "Details";
$_data['text_6'] 		= "Maintenance Cost Details";


?>