<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['add_title_text'] 				= "Add New Maintenance Cost";
$_data['add_msg'] 						= "Added Maintenance Cost Successfully";
$_data['update_title_text'] 			= "Update Maintenance Cost";
$_data['update_msg'] 					= "Updated Maintenance Cost Successfully";
$_data['maintenance_cost'] 				= "Maintenance Cost";
$_data['add_m_cost'] 					= "Add Maintenance Cost";
$_data['m_cost_entry_form'] 			= "Maintenance Cost Entry Form";
$_data['date'] 							= "Date";
$_data['month'] 						= "Month";
$_data['select_month'] 					= "Select Month";
$_data['year'] 							= "Year";
$_data['select_year'] 					= "Select Year";
$_data['text_1'] 						= "Maintenance Title";
$_data['text_2'] 						= "Amount"; 
$_data['text_3'] 						= "Details";
?>