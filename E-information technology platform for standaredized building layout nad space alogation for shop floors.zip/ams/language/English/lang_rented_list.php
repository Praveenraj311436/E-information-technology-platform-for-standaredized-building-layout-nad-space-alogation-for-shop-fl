<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['renter_list'] 								= "Renter List";
$_data['update_rent'] 								= "Update Rent";
$_data['add_new_form_field_text_0'] 				= "Image";
$_data['add_new_form_field_text_1'] 				= "Renter Name";
$_data['add_new_form_field_text_2'] 				= "Email ";
$_data['add_new_form_field_text_3'] 				= "Password";
$_data['add_new_form_field_text_4'] 				= "Contact";
$_data['add_new_form_field_text_5'] 				= "Address";
$_data['add_new_form_field_text_6'] 				= "NID(National ID)";
$_data['add_new_form_field_text_7'] 				= "Floor No";
$_data['add_new_form_field_text_8'] 				= "Available Unit No";
$_data['add_new_form_field_text_9'] 				= "Advance Rent";
$_data['add_new_form_field_text_10'] 				= "Rent Per Month";
$_data['add_new_form_field_text_11'] 				= "Issue Date";
$_data['add_new_form_field_text_12'] 				= "Rent Month";
$_data['add_new_form_field_text_13'] 				= "Rent Year";
$_data['add_new_form_field_text_14'] 				= "Status";
$_data['add_new_form_field_text_15'] 				= "Preview";
$_data['add_new_form_field_text_16'] 				= "Active";
$_data['add_new_form_field_text_17'] 				= "Expired";
$_data['add_new_renter_information_breadcam'] 		= "Renter Information";
$_data['add_new_rent_breadcam'] 					= "Add Rent";
$_data['rented_details'] 							= "Rented Details";
$_data['added_renter_successfully'] 				= "Added Renter Information Successfully";
$_data['update_renter_successfully'] 				= "Updated Renter Information Successfully";
$_data['delete_renter_information'] 				= "Deleted Renter Information Successfully.";

?>