<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Add New Building Information";
$_data['text_2'] 		= "Building";
$_data['text_3'] 		= "Add Building Info";
$_data['text_4'] 		= "Building Information";
$_data['text_5'] 		= "Name";
$_data['text_6'] 		= "Address";
$_data['text_7'] 		= "Security Guard Mobile";
$_data['text_8'] 		= "Secretary Mobile";
$_data['text_9'] 		= "Moderator Mobile";
$_data['text_10'] 		= "Buildig Make Year";
$_data['text_11'] 		= "Builder Information";
$_data['text_12'] 		= "Phone";
$_data['text_13'] 		= "Building Image";
$_data['text_14'] 		= "Select Year";

?>