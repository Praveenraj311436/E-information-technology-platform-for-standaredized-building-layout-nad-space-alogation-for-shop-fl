<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Month Setup";
$_data['text_2'] 		= "Month Entry Form";
$_data['text_3'] 		= "Month Name";
$_data['text_4'] 		= "Month List";
$_data['text_5'] 		= "Added Month Information Successfully";
$_data['text_6'] 		= "Updated Month Information Successfully";
$_data['text_7'] 		= "Deleted Month Information Successfully";
$_data['text_8'] 		= "Month Details";


?>