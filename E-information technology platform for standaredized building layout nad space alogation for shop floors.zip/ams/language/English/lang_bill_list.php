<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 		= "Bill List";
$_data['text_1_1'] 		= "Bill Details";
$_data['text_2'] 		= "Bill Information";
$_data['text_3'] 		= "Add Bill";
$_data['text_4'] 		= "Bill Entry Form";
$_data['text_5'] 		= "Bill Type";
$_data['text_6'] 		= "Select Type";
$_data['text_7'] 		= "Issue Date";
$_data['text_8'] 		= "Bill Month";
$_data['text_9'] 		= "Select Month";
$_data['text_10'] 		= "Bill Year";
$_data['text_11'] 		= "Select Year";
$_data['text_12'] 		= "Total Amount";
$_data['text_13'] 		= "Deposit Bank Name";
$_data['text_14'] 		= "Details";
$_data['text_15'] 		= "Added Bill Successfully";
$_data['text_16'] 		= "Updated Bill Successfully";
$_data['text_17'] 		= "Deleted Bill Information Successfully";

?>