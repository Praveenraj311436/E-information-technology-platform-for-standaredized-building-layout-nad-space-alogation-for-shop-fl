<?php
//Website Menu Language Conversion
//English Package
//copyright: sakosys.com

$_data['text_1'] 				= "Unit List";
$_data['text_2'] 				= "Floor No";
$_data['text_3'] 				= "Unit No";
$_data['text_4'] 				= "Unit Details";
$_data['text_5'] 				= "Owner's Name";
$_data['text_6'] 				= "Email";
$_data['text_7'] 				= "Contact No";
$_data['text_8'] 				= "Address";
$_data['text_9'] 				= "Owner Dashboard";

?>