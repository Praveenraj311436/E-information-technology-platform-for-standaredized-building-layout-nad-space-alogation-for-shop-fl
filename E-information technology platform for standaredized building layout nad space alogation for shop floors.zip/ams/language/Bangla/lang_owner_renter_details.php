<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাড়াটিয়া বিস্তারিত";
$_data['text_2'] 		= "ভাড়াটিয়ার নাম";
$_data['text_3'] 		= "ই-মেইল";
$_data['text_4'] 		= "যোগাযোগ";
$_data['text_5'] 		= "ঠিকানা";
$_data['text_6'] 		= "মেঝে সংখ্যা";
$_data['text_7'] 		= "ইউনিট সংখ্যা";
$_data['text_8'] 		= "অগ্রিম ভাড়া";
$_data['text_9'] 		= "ভাড়া তারিখ";
$_data['text_10'] 		= "প্রতি মাসে ভাড়া";

?>