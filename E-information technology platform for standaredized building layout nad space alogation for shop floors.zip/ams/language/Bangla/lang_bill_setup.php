<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "বিল প্রকার সেটআপ";
$_data['text_2'] 		= "বিল প্রকার এন্ট্রি ফর্ম";
$_data['text_3'] 		= "বিল প্রকার";
$_data['text_4'] 		= "বিল প্রকার তালিকা";
$_data['text_5'] 		= "ডাটা যোগ করার পুর্বে অনুগ্রহ করে রিসেট করুন";
$_data['text_6'] 		= "বিল প্রকার বিবরণ";
$_data['text_7'] 		= "বিল টাইপ সফলভাবে যোগ হয়েছে";
$_data['text_8'] 		= "বিল টাইপ সফলভাবে পরিবর্তন হয়েছে";
$_data['text_9'] 		= "বিল টাইপ সফলভাবে মুছা হয়েছে";

?>