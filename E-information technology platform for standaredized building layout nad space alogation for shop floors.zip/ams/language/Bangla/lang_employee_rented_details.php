<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ভাড়া বিস্তারিত";
$_data['text_2'] 		= "ভাড়া নাম";
$_data['text_3'] 		= "যোগাযোগ";
$_data['text_4'] 		= "ইউনিট সংখ্যা";
$_data['text_5'] 		= "অগ্রিম ভাড়া";
$_data['text_6'] 		= "প্রতি মাসে ভাড়া";
$_data['text_7'] 		= "অবস্থা";
$_data['text_8'] 		= "ই-মেইল";
$_data['text_9'] 		= "পাসওয়ার্ড";
$_data['text_10'] 		= "ঠিকানা";
$_data['text_11'] 		= "জাতীয় পরিচয়পত্র";
$_data['text_12'] 		= "ভাড়া স্টার্ট তারিখ";
$_data['dashboard'] 	= "ড্যাশবোর্ড";
$_data['active'] 		= "সক্রিয়";
$_data['expired'] 		= "মেয়াদোত্তীর্ণ";

?>