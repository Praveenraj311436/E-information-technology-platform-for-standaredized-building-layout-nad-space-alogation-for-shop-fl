<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1_1'] 		= "অথিতি তালিকা";
$_data['text_2'] 		= "অথিতি";
$_data['text_3'] 		= "অথিতি যোগ";
$_data['text_4'] 		= "অথিতি এন্ট্রি ফরম";
$_data['text_5'] 		= "ইস্যু তারিখ";
$_data['text_6'] 		= "নাম";
$_data['text_7'] 		= "ফোন";
$_data['text_8'] 		= "ঠিকানা";
$_data['text_9'] 		= "ফ্লোর নম্বর";
$_data['text_10'] 		= "ফ্লোর নির্বাচন";
$_data['text_11'] 		= "ইউনিট নম্বর";
$_data['text_12'] 		= "ইউনিট নির্বাচন";
$_data['text_13'] 		= "প্রবেশ সময়";
$_data['text_14'] 		= "বাহির সময়";
$_data['text_15'] 		= "অথিতি সফলভাবে যোগ হয়েছে";
$_data['text_16'] 		= "অথিতি পরিবর্তন";
$_data['text_17'] 		= "অথিতি সফলভাবে পরিবর্তন হয়েছে";
$_data['text_18'] 		= "অথিতি সফলভাবে মুছে ফেলা হয়েছে";

?>