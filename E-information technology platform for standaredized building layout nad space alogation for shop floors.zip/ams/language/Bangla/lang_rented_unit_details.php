<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ইউনিট বিস্তারিত";
$_data['text_5'] 		= "নাম";
$_data['text_6'] 		= "ই-মেইল";
$_data['text_7'] 		= "যোগাযোগ";
$_data['text_8'] 		= "ঠিকানা";
$_data['text_9'] 		= "মেঝে সংখ্যা";
$_data['text_10'] 		= "ইউনিট সংখ্যা";
$_data['text_11'] 		= "অগ্রিম পরিশোধ";
$_data['text_12'] 		= "প্রতি মাসে ভাড়া";
$_data['text_13'] 		= "ভাড়া তারিখ";
$_data['text_14'] 		= "জাতীয় পরিচয়পত্র";
$_data['text_19'] 		= "ড্যাশবোর্ড";

?>