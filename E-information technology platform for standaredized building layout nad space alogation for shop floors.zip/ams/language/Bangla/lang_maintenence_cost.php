<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "রক্ষণাবেক্ষণ খরচ তালিকা";
$_data['text_2'] 		= "রক্ষণাবেক্ষণ শিরোনাম";
$_data['text_3'] 		= "তারিখ";
$_data['text_4'] 		= "পরিমাণ";
$_data['text_5'] 		= "বিস্তারিত";
$_data['text_6'] 		= "রক্ষণাবেক্ষণ খরচ বিবরণ";

?>