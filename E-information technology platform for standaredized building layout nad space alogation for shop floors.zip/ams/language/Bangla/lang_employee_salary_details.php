<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "বেতন বিস্তারিত";
$_data['text_2'] 		= "প্রদানের তারিখ";
$_data['text_3'] 		= "মাস নাম";
$_data['text_4'] 		= "বছর";
$_data['text_5'] 		= "পরিমাণ";
$_data['text_6'] 		= "কর্মচারী ড্যাশবোর্ড";
$_data['text_7'] 		= "কর্মচারী বিবরণ";
$_data['text_8'] 		= "কর্মকর্তার নাম";
$_data['text_9'] 		= "ই-মেইল";
$_data['text_10'] 		= "যোগাযোগ";
$_data['text_11'] 		= "বর্তমান ঠিকানা";
$_data['text_12'] 		= "স্থায়ী ঠিকানা";

?>