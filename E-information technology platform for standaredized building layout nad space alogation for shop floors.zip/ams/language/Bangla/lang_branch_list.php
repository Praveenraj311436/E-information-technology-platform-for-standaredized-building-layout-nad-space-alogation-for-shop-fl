<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "শাখা যোগ";
$_data['text_1_1'] 		= "শাখা পরিবর্তন";
$_data['text_2'] 		= "শাখা";
$_data['text_3'] 		= "শাখা এন্ট্রি ফর্ম";
$_data['text_4'] 		= "নাম ";
$_data['text_5'] 		= "ই-মেইল";
$_data['text_6'] 		= "যোগাযোগের নম্বর";
$_data['text_7'] 		= "ঠিকানা";
$_data['text_8'] 		= "অবস্থা";
$_data['text_9'] 		= "সক্ষম করা";
$_data['text_10'] 		= "অক্ষম";
$_data['text_11'] 		= "শাখা তথ্য সফলভাবে যোগ করা হয়েছে";
$_data['text_12'] 		= "শাখা তথ্য সফলভাবে পরিবর্তিত হয়েছে";
$_data['text_13'] 		= "শাখা তথ্য সফলভাবে মুছে ফেলা হয়েছে";
$_data['text_14']		= "শাখা তালিকা";
$_data['text_15'] 		= "শাখার নাম";
$_data['text_16']  		= "শাখা বিস্তারিত";
$_data['text_17'] 		= "ড্যাশবোর্ড";

?>