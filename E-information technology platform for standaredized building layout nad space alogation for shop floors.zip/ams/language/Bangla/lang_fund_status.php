<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "ফান্ড স্থিতি";
$_data['text_2'] 		= "ছবি";
$_data['text_3'] 		= "তারিখ";
$_data['text_4'] 		= "মালিক নাম";
$_data['text_5'] 		= "মাস";
$_data['text_6'] 		= "বছর";
$_data['text_7'] 		= "মুল্য";
$_data['text_8'] 		= "উদ্দেশ্য";
$_data['text_9'] 		= "কস্ট স্থিতি বজায় রাখা";
$_data['text_10'] 		= "খরচ শিরোনাম";
$_data['text_11'] 		= "বিস্তারিত";
$_data['text_12'] 		= "অবশিষ্ট ব্যালেন্স";
$_data['text_13'] 		= "তথ্য মুদ্রণ";

?>