<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "নতুন বিল্ডিং তথ্য যোগ";
$_data['text_2'] 		= "ভবন";
$_data['text_3'] 		= "বিল্ডিং তথ্য যোগ";
$_data['text_4'] 		= "বিল্ডিং তথ্য";
$_data['text_5'] 		= "নাম";
$_data['text_6'] 		= "ঠিকানা";
$_data['text_7'] 		= "সিকিউরিটি গার্ড মোবাইল";
$_data['text_8'] 		= "সম্পাদক মোবাইল";
$_data['text_9'] 		= "নিয়ামক মোবাইল";
$_data['text_10'] 		= "ভবন নির্মাণ বছর";
$_data['text_11'] 		= "নির্মাতা তথ্য";
$_data['text_12'] 		= "ফোন";
$_data['text_13'] 		= "বিল্ডিং চিত্র";
$_data['text_14'] 		= "বছর নির্বাচন";

?>