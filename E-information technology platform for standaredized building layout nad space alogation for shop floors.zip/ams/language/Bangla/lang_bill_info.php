<?php
//Website Menu Language Conversion
//Bangla Package
//copyright: sakosys.com

$_data['text_1'] 		= "বিল প্রতিবেদন";
$_data['text_2'] 		= "বিল প্রকার";
$_data['text_3'] 		= "তারিখ";
$_data['text_4'] 		= "মাস";
$_data['text_5'] 		= "বছর";
$_data['text_6'] 		= "সর্বমোট পরিমাণ";
$_data['text_7'] 		= "ব্যাঙ্ক নাম";
$_data['text_8'] 		= "বিস্তারিত";

?>